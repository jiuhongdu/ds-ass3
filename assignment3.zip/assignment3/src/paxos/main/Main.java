package paxos.main;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import paxos.doer.Member;
import paxos.util.PaxosUtil;

/**
 * The main function
 *
 */
public class Main {
	private static final int NUM_OF_MEMBER = 9;
	public static CountDownLatch latch = new CountDownLatch(NUM_OF_MEMBER);

	private static final int portStart = 12121;

	public static void main(String[] args) {

		for (String s : args) {
			if ("immediate".equals(s)) {
				PaxosUtil.IMMEDIATE_RESPONCE = true;
				System.out.println("***** Set all members to have immediate responses *****");
			}
		}
		List<Integer> acceptorPorts = new ArrayList<>();
		List<Member> members = new ArrayList<>();
		for (int i = 0; i < NUM_OF_MEMBER; i++) {
			acceptorPorts.add(portStart + i);
		}

		for (int i = 0; i < NUM_OF_MEMBER; i++) {
			Member mem = new Member(portStart + i, i + 1, "M" + (i + 1), NUM_OF_MEMBER, acceptorPorts);
			members.add(mem);
		}

		System.out.println("The Day has come !");
		for (int i = 0; i < NUM_OF_MEMBER; i++) {
			members.get(i).theDayCome();
		}

		for (int i = 0; i < 3; i++) {
			try {
				members.get(i).getProposer().join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		// So let's go over here and say that the results have been selected
		System.out.println("A successful election!" + PaxosUtil.getResult() + " Elected!");
		System.exit(0);
	}
}
