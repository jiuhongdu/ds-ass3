package paxos.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import paxos.doer.Member;

/**
 * Utility class
 * 
 * @author linjx
 *
 */
public class PaxosUtil {

	private static final int CHANCE_TO_LOST = 4; // There's a 1/4 chance that the response will be lost because of the network
	private static final int CHANCE_TO_CRASH_OR_BACK = 10; // There's a 1 in 10 chance of crashing
	private static boolean M3Crashed = false;
	private static final int CRASH_TIME = 10;
	private static int m_id = 0;
	private static Random random = new Random();
	private static final int DELAY_M2 = 10;
	private static final int DELAY_M3 = 5;
	// public static ExecutorService es = Executors.newCachedThreadPool();
	private static String result = "";
	public static boolean IMMEDIATE_RESPONCE = false;
	public static final List<Member> members = new ArrayList<>();

	/*
	 * @brief Proposal sequence number generation: unique and incrementing. Refer to the proposed generation algorithm in Chubby
	 * 
	 * @param myID ID of the proposer
	 * 
	 * @param numCycle Generate the proposed rotation
	 * 
	 * @param Number of proposers
	 * 
	 * @return The generated proposal ID
	 * 
	 */
	public static int generateId(int myID, int numCycle, int proposerCount) {
		// So let's try another algorithm here, and it always feels like M8, M9 works
		int id = numCycle * proposerCount + myID;
		return id;
	}

	// Random sleep, simulate network delay
	public static int sleepRandom(int ID) {
		int timeInMs = 0;
		if (IMMEDIATE_RESPONCE)
			return 0;
		if (ID == 1) {
			timeInMs = 0;
		} else if (ID == 2) {
			timeInMs = random.nextInt(DELAY_M2);
		} else if (ID == 3) {
			timeInMs = random.nextInt(DELAY_M3);
		}

		try {
			Thread.sleep(timeInMs);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return timeInMs;
	}

	public static boolean isM3Crashed() {
		int x = random.nextInt(CHANCE_TO_CRASH_OR_BACK);
		if (0 == x) {
			if (M3Crashed) {
				M3Crashed = false;
				System.out.println("***** M3 is back online *****");
			} else {
				M3Crashed = true;
				System.out.println("***** M3 is offline *****");
				try {
					Thread.sleep(CRASH_TIME);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		return M3Crashed;
	}

	public static boolean isLost() {
		int x = random.nextInt(CHANCE_TO_LOST);
		if (0 == x)
			return true;
		return false;
	}

	public static void printStr(String string) {
		System.out.println(string);
	}

	public static String getResult() {
		return result;
	}

	public static void setResult(String result) {
		PaxosUtil.result = result;
	}

}
