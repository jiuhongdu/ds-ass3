package paxos.util;

/**
 * 
 * @author linjx Performance record
 */
public class PerformanceRecord {
	private static final int MAX_ID_VALUE = 200;
	private static PerformanceRecord instance = null;
	private String[] despArray;
	private long[] startArray;
	private int recordCount;

	// Instance acquisition method
	public static PerformanceRecord getInstance() {
		if (null == instance) {
			synchronized (PerformanceRecord.class) {
				if (null == instance)
					instance = new PerformanceRecord();
			}
		}
		return instance;
	}

	private PerformanceRecord() {
		despArray = new String[MAX_ID_VALUE];
		startArray = new long[MAX_ID_VALUE];
		recordCount = 0;
	}

	// @brief Start the performance record. After this function is called, the timing starts
	// @param description A brief description of the information
	// @param ID The id of this performance record cannot be repeated。 ID >= 0 && ID < 200;
	// @return void
	public void start(String description, int ID) {
		despArray[ID] = description;
		startArray[ID] = System.currentTimeMillis();
	}

	// @brief End the performance record with id as ID
	// @param ID The ID you set when you call Start
	// @return void
	public void end(int ID) {
		long endTime = System.currentTimeMillis();
		String performStr = String.format("%s Time consuming to%d ms.", despArray[ID], endTime - startArray[ID]);
		printPerform(performStr);
		// help GC
		despArray[ID] = null;
	}

	public void printPerform(String performStr) {
		System.out.println(performStr);
	}
}
