package paxos.doer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import paxos.bean.AcceptorStatus;
import paxos.bean.CommitResult;
import paxos.bean.PrepareResult;
import paxos.bean.Proposal;
import paxos.main.Main;
import paxos.util.PaxosUtil;
import paxos.util.PerformanceRecord;

/**
 * proposed
 * 
 * @author linjx
 *
 */
public class Proposer extends Thread {

	// The serial number
	// If it is M1, no special processing is required. If it is M2, a random delay can be added for each receiving and sending. Then, if you work in cafe, the delay can be eliminated	// 如果是M3，每一个接受和发送都增加一个（较低）延迟，但是有一定概率直接丢失输入
	int myID = 0;

	// The name of the proposer
	private String name;
	// The proposer's proposal
	private Proposal proposal;

	// Whether a proposal has been confirmed by a majority of decision makers
	private boolean voted;
	// The minimum number of most decision makers
	private int halfCount;

	private int proposerCount;

	private int numCycle = 0;

	// policymakers
	private List<Integer> acceptorPorts;

	private ObjectOutputStream oos;
	private ObjectInputStream ois;

	public Proposer(int myID, String name, int proposerCount, List<Integer> acceptorPorts) {
		this.myID = myID;
		this.name = name;
		this.acceptorPorts = acceptorPorts;
		this.proposerCount = proposerCount;
		numCycle = 0;
		voted = false;
		halfCount = acceptorPorts.size() / 2 + 1;
		this.proposal = new Proposal(PaxosUtil.generateId(myID, numCycle, proposerCount), myID + "#Proposal", name,
				Proposal.PREPARE);
		numCycle++;
	}

	// The process of preparing a proposal, with the support of most decision makers, goes to the stage of confirming the proposal.
	public boolean prepare() {

		PrepareResult prepareResult = null;

		boolean isContinue = true;
		// Number of commitments received
		int promisedCount = 0;

		do {
			if (myID == 3 && PaxosUtil.isM3Crashed()) {
				continue;
			}
			List<Proposal> promisedProposals = new ArrayList<Proposal>();
			List<Proposal> acceptedProposals = new ArrayList<Proposal>();
			promisedCount = 0;

			System.out.println(this.name + " trying to propose at " + System.currentTimeMillis());
			for (Integer port : acceptorPorts) {

				// prepareResult = acceptor.onPrepare(proposal);
				Socket s = null;
				try {
					s = new Socket("localhost", port);
					proposal.setType(Proposal.PREPARE);

					oos = new ObjectOutputStream(s.getOutputStream());

					// Add delay
					PaxosUtil.sleepRandom(myID);
					oos.writeObject(proposal);
					PaxosUtil.sleepRandom(myID);

					ois = new ObjectInputStream(s.getInputStream());
					prepareResult = (PrepareResult) ois.readObject();
					if(prepareResult != null && prepareResult.isPromised()){
						System.out.println(this.name + "'s prepare request='" + proposal.getValue()+"' is promised");
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if (s != null)
							s.close();
						if (oos != null) {
							oos.close();
						}
						if (ois != null) {
							oos.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

				// Analog network anomaly
				if (null == prepareResult) {
					continue;
				}

				
				if (prepareResult.isPromised()) {
					promisedCount++;
				} else {
					// Policymakers have promised a higher id
					if (prepareResult.getAcceptorStatus() == AcceptorStatus.PROMISED) {
						promisedProposals.add(prepareResult.getProposal());
					}
					// The decision makers have already adopted a proposal
					if (prepareResult.getAcceptorStatus() == AcceptorStatus.ACCEPTED) {
						acceptedProposals.add(prepareResult.getProposal());
					}
				}
			} // end of for

			// Get the commitment of most decision makers
			// We can proceed to the second stage: proposal submission
			if (promisedCount >= halfCount) {
				System.out.println(this.name + " get a majority promise.");
				break;
			}
			// Proposer is a way of knowing if a proposal should be stopped
			Proposal votedProposal = votedEnd(acceptedProposals);
			// Half of the decision makers have already approved the bill
			if (votedProposal != null) {
				return true;
			}

			Proposal maxIdAcceptedProposal = getMaxIdProposal(acceptedProposals);
			// The decision with the largest serial number has been selected by the decision maker as its own decision。
			if (maxIdAcceptedProposal != null) {
				proposal.setId(PaxosUtil.generateId(myID, numCycle, proposerCount));
				proposal.setValue(maxIdAcceptedProposal.getValue());
				System.out.println(this.name + " choose " + maxIdAcceptedProposal.getValue() + "As a new proposal");
			} else {
				proposal.setId(PaxosUtil.generateId(myID, numCycle, proposerCount));
			}
			// Each time a vote is called, one is added
			numCycle++;
		} while (isContinue);
		return false;
	}

	// With the commitment of most decision makers, proposal confirmation begins
	public boolean commit() {

		boolean isContinue = true;

		// The number of decision makers who have accepted the proposal
		int acceptedCount = 0;
		do {
			List<Proposal> acceptedProposals = new ArrayList<Proposal>();
			acceptedCount = 0;
			for (Integer port : acceptorPorts) {

				CommitResult commitResult = null;
				Socket s = null;
				ObjectOutputStream oos = null;
				ObjectInputStream ois = null;
				try {
					s = new Socket("localhost", port);

					oos = new ObjectOutputStream(s.getOutputStream());
					proposal.setType(Proposal.COMMIT);
					PaxosUtil.sleepRandom(myID);
					oos.writeObject(proposal);

					PaxosUtil.sleepRandom(myID);
					ois = new ObjectInputStream(s.getInputStream());
					commitResult = (CommitResult) ois.readObject();

				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} finally {
					try {
						if (s != null)
							s.close();
						if (oos != null) {
							oos.close();
						}
						if (ois != null) {
							ois.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

				// Analog network anomaly
				if (null == commitResult) {
					continue;
				}
				// The proposal was accepted by decision makers.
				if (commitResult.isAccepted()) {
					System.out.println(this.name + "'s commit = \'" + proposal.getValue() +"\' is accepted");
					acceptedCount++;
				} else {
					acceptedProposals.add(commitResult.getProposal());
				}
			}

			// The fact that the proposal has been accepted by more than half of the decision makers indicates that the proposal has been chosen.
			if (acceptedCount >= halfCount) {
				PaxosUtil.setResult(proposal.getValue());
				System.out.println(name + " : The proposal has been voted on:" + proposal);
				return true;
			} else {
				Proposal maxIdAcceptedProposal = getMaxIdProposal(acceptedProposals);
				// Select the decision with the largest serial number in the problem proposal by the decision maker, re-generate the increasing ID, and change its value to the value with the largest serial number.
				// This is a prediction that the maxIdAccecptedProposal is most likely to be accepted by more than half of the decision makers.
				if (maxIdAcceptedProposal != null) {
					proposal.setId(PaxosUtil.generateId(myID, numCycle, proposerCount));
					proposal.setValue(maxIdAcceptedProposal.getValue());
				} else {
					proposal.setId(PaxosUtil.generateId(myID, numCycle, proposerCount));
				}

				numCycle++;
				// Step back to the decision preparation stage
				if (prepare())
					return true;
			}

		} while (isContinue);

		return true;
	}

	// Get the proposal with the largest serial number
	private Proposal getMaxIdProposal(List<Proposal> acceptedProposals) {

		if (acceptedProposals.size() > 0) {
			Proposal retProposal = acceptedProposals.get(0);
			for (Proposal proposal : acceptedProposals) {
				if (proposal.getId() > retProposal.getId())
					retProposal = proposal;
			}
			return retProposal;
		}
		return null;
	}

	// Is there a proposal that has been accepted by a majority of decision makers
	private Proposal votedEnd(List<Proposal> acceptedProposals) {
		Map<Proposal, Integer> proposalCount = countAcceptedProposalCount(acceptedProposals);
		for (Entry<Proposal, Integer> entry : proposalCount.entrySet()) {
			if (entry.getValue() >= halfCount) {
				voted = true;
				return entry.getKey();
			}
		}
		return null;
	}

	// Calculate the count for each accepted proposal that the decision maker responds to
	private Map<Proposal, Integer> countAcceptedProposalCount(List<Proposal> acceptedProposals) {
		Map<Proposal, Integer> proposalCount = new HashMap<>();
		for (Proposal proposal : acceptedProposals) {
			// The decision maker did not respond, or the network was abnormal
			if (null == proposal)
				continue;
			int count = 1;
			if (proposalCount.containsKey(proposal)) {
				count = proposalCount.get(proposal) + 1;
			}
			proposalCount.put(proposal, count);
		}

		return proposalCount;
	}

	@Override
	public void run() {
		// If it's M4-9, just quit
		if (myID > 3)
			return;
		// To ensure that the proposer starts after an Acceptor
		try {
			Main.latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// The singleton pattern
		PerformanceRecord.getInstance().start("Proposer" + myID, myID);

		prepare();
		commit();

		PerformanceRecord.getInstance().end(myID);
	}

	@Override
	public String toString() {
		return "Proposer [myID=" + myID + ", name=" + name + "]";
	}
}
