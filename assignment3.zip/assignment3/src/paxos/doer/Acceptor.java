package paxos.doer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import paxos.bean.AcceptorStatus;
import paxos.bean.CommitResult;
import paxos.bean.PrepareResult;
import paxos.bean.Proposal;
import paxos.main.Main;
import paxos.util.PaxosUtil;

/**
 * Decision makers
 * 
 * @author linjx
 *
 */
public class Acceptor extends Thread {

	private int port;
	private int myID;
	private boolean isContinue = true;

	// Record the status of the processed proposal
	private AcceptorStatus status = AcceptorStatus.NONE;
	// A proposal to document the latest commitments
	private Proposal promisedProposal = new Proposal();
	// Record the latest approved proposals
	private Proposal acceptedProposal = new Proposal();

	// Lock this preparation function. Simultaneous access is not allowed. Simulates a single decision maker processing a request sequentially.
	public synchronized PrepareResult onPrepare(Proposal szProposal) {
		PrepareResult prepareResult = new PrepareResult();

		// If it is M3, it may be lost
		if (myID == 3 && PaxosUtil.isM3Crashed()) {
			return null;
		}
		switch (status) {
			// NONE indicates that no proposer has been promised before
			// At this point, accept the proposal
			case NONE:
				prepareResult.setAcceptorStatus(AcceptorStatus.NONE);
				prepareResult.setPromised(true);
				prepareResult.setProposal(null);
				// To change its state, the proposer has been committed, and the proposal has been recorded.
				status = AcceptorStatus.PROMISED;
				promisedProposal.copyFromInstance(szProposal);
				return prepareResult;
			// Any proposer has been promised
			case PROMISED:
				// Judge the order of proposals and commit only to relatively new proposals
				if (promisedProposal.getId() > szProposal.getId()) {
					prepareResult.setAcceptorStatus(status);
					prepareResult.setPromised(false);
					prepareResult.setProposal(promisedProposal);
					return prepareResult;
				} else {
					promisedProposal.copyFromInstance(szProposal);
					prepareResult.setAcceptorStatus(status);
					prepareResult.setPromised(true);
					prepareResult.setProposal(promisedProposal);
					return prepareResult;
				}
				// The proposal has been approved
			case ACCEPTED:
				// If it's the same proposal, it's just the sequence number goes up
				// Approve the proposal and update the serial number.
				if (promisedProposal.getId() < szProposal.getId()
						&& promisedProposal.getValue().equals(szProposal.getValue())) {
					promisedProposal.setId(szProposal.getId());
					prepareResult.setAcceptorStatus(status);
					prepareResult.setPromised(true);
					prepareResult.setProposal(promisedProposal);
					return prepareResult;
				} else { // Otherwise, it is not approved
					prepareResult.setAcceptorStatus(status);
					prepareResult.setPromised(false);
					prepareResult.setProposal(acceptedProposal);
					return prepareResult;
				}
			default:
				// return null;
		}

		return null;
	}

	// Lock this commit function, which does not allow simultaneous access, to simulate a single decision maker's serial decision
	public synchronized CommitResult onCommit(Proposal szProposal) {
		CommitResult commitResult = new CommitResult();
		// If it is M3, it may be lost
		// If it is M3, it may be lost
		if (myID == 3 && PaxosUtil.isM3Crashed()) {
			return null;
		}
		switch (status) {
			// There can be no such state
			case NONE:
				return null;
			// Proposals have been promised
			case PROMISED:
				// Determine the serial number size of the COMMIT proposal and the commitment proposal
				// Greater than, accept the proposal.
				if (szProposal.getId() >= promisedProposal.getId()) {
					promisedProposal.copyFromInstance(szProposal);
					acceptedProposal.copyFromInstance(szProposal);
					status = AcceptorStatus.ACCEPTED;
					commitResult.setAccepted(true);
					commitResult.setAcceptorStatus(status);
					commitResult.setProposal(promisedProposal);
					return commitResult;

				} else { // Less than, reject the proposal
					commitResult.setAccepted(false);
					commitResult.setAcceptorStatus(status);
					commitResult.setProposal(promisedProposal);
					return commitResult;
				}
				// The proposal has been accepted
			case ACCEPTED:
				// Accept the same proposal with a larger serial number
				if (szProposal.getId() > acceptedProposal.getId()
						&& szProposal.getValue().equals(acceptedProposal.getValue())) {
					acceptedProposal.setId(szProposal.getId());
					commitResult.setAccepted(true);
					commitResult.setAcceptorStatus(status);
					commitResult.setProposal(acceptedProposal);
					return commitResult;
				} else { // Otherwise, reject the proposal
					commitResult.setAccepted(false);
					commitResult.setAcceptorStatus(status);
					commitResult.setProposal(acceptedProposal);
					return commitResult;
				}
		}

		return null;
	}

	public Acceptor(int port, int myID) {
		this.port = port;
		this.myID = myID;
	}

	@Override
	public void run() {
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
		// To ensure that the proposer starts after an Acceptor
		Main.latch.countDown();
		boolean isContinue = true;
		while (isContinue) {
			Socket s = null;
			ObjectOutputStream oos = null;
			ObjectInputStream ois = null;
			try {
				s = ss.accept();
				ois = new ObjectInputStream(s.getInputStream());
				Object obj = ois.readObject();
				Proposal proposal = (Proposal) obj;
				oos = new ObjectOutputStream(s.getOutputStream());
				if (proposal.getType() == Proposal.PREPARE) {
					PrepareResult prepareResult = onPrepare(proposal);
					// Sent to the proposer
					oos.writeObject(prepareResult);
				} else if (proposal.getType() == Proposal.COMMIT) {
					CommitResult commitResult = onCommit(proposal);
					oos.writeObject(commitResult);
				}
			} catch (IOException | ClassNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					if (s != null)
						s.close();
					if (oos != null) {
						oos.close();
					}
					if (ois != null) {
						ois.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		try {
			if (ss != null)
				ss.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public String toString() {
		return "Acceptor [port=" + port + "]";
	}

	public boolean isContinue() {
		return isContinue;
	}

	public void setContinue(boolean isContinue) {
		this.isContinue = isContinue;
	}
}
