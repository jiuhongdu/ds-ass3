package paxos.doer;

import java.util.List;

public class Member {
    private Proposer proposer;
    private Acceptor acceptor;
    private String name;
    private int port;

    public Member(int port, int myID, String name, int proposerCount, List<Integer> acceptorPorts) {
        acceptor = new Acceptor(port, myID);
        proposer = new Proposer(myID, name, proposerCount, acceptorPorts);
    }

    public int getPort() {
        return port;
    }

    public void theDayCome() {
        acceptor.start();
        proposer.start();
    }

    public Proposer getProposer() {
        return proposer;
    }

    public Acceptor getAcceptor() {
        return acceptor;
    }

}
