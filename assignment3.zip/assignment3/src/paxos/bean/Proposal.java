package paxos.bean;

import java.io.Serializable;

/**
 * The proposal
 * 
 * @author linjx
 *
 */
public class Proposal implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 887075599025207235L;
	public static final int PREPARE = 0;
	public static final int COMMIT = 1;
	// The name of the proposed
	String name;
	// The serial number of the proposal
	int id;
	// The value of the proposal
	String value;
	// The proposal type
	int type;

	public Proposal() {

	}

	public Proposal(int id, String name, String value, int type) {
		this.id = id;
		this.name = name;
		this.value = value;
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void copyFromInstance(Proposal proposal) {
		this.id = proposal.id;
		this.name = proposal.name;
		this.value = proposal.value;
	}

	@Override
	public String toString() {
		return "Proposal [name=" + name + ", id=" + id + ", value=" + value + "]";
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
