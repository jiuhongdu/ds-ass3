package paxos.bean;

import java.io.Serializable;

/**
 * When the proposer confirms to the decision maker, the decision maker's confirmation reply
 * 
 * @author linjx
 *
 */
public class CommitResult implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -4448963984378363553L;
	// Whether the proposal submitted is accepted or not
	boolean accepted = false;
	// State of decision maker
	AcceptorStatus acceptorStatus = AcceptorStatus.NONE;
	// Return to decision makers for confirmed proposals
	Proposal proposal;

	public boolean isAccepted() {
		return accepted;
	}

	public void setAccepted(boolean accepted) {
		this.accepted = accepted;
	}

	public AcceptorStatus getAcceptorStatus() {
		return acceptorStatus;
	}

	public void setAcceptorStatus(AcceptorStatus acceptorStatus) {
		this.acceptorStatus = acceptorStatus;
	}

	public Proposal getProposal() {
		return proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	@Override
	public String toString() {
		return "CommitResult [accepted=" + accepted + ", acceptorStatus=" + acceptorStatus + ", proposal=" + proposal
				+ "]";
	}
}
