package paxos.bean;

/**
 * The decision maker records the status of the processed proposal
 * 
 * @author linjx
 *
 */
public enum AcceptorStatus {
	ACCEPTED, // accept
	PROMISED, // promise
	NONE // No proposal has been processed
}
