package paxos.bean;

import java.io.Serializable;

/**
 * The decision maker's response to the proposer's prepared proposal
 * 
 * @author linjx
 *
 */
public class PrepareResult implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 2253820941402786101L;
	// Whether the promised
	private boolean isPromised;
	// State of decision maker
	private AcceptorStatus acceptorStatus = AcceptorStatus.NONE;
	// Decision makers return to the proposal.
	private Proposal proposal;

	public boolean isPromised() {
		return isPromised;
	}

	public void setPromised(boolean isPromised) {
		this.isPromised = isPromised;
	}

	public AcceptorStatus getAcceptorStatus() {
		return acceptorStatus;
	}

	public void setAcceptorStatus(AcceptorStatus acceptorStatus) {
		this.acceptorStatus = acceptorStatus;
	}

	public Proposal getProposal() {
		return proposal;
	}

	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	@Override
	public String toString() {
		return "PrepareResult [isPromised=" + isPromised + ", acceptorStatus=" + acceptorStatus + ", proposal="
				+ proposal + "]";
	}

}
